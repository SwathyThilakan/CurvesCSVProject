﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IBM.WMQ;
using System.Net;
using System.Collections;
using System.Configuration;


namespace CurvesCSVClient
{
    public class MQClient
    {
        public string Hostname;
        public string HostIp;
        public string Port;
        public string Channel;
        public string Queuename;
        public Hashtable connectionProperties;

        public MQClient()
        {
            String qManager = System.Configuration.ConfigurationManager.AppSettings["qManager"];
               
            // Define the name of your host connection (applies to client connections only) 
            Hostname = Dns.GetHostName();
            HostIp = Dns.GetHostEntry(Hostname).AddressList[1].ToString();
            Port = System.Configuration.ConfigurationManager.AppSettings["Port"];
            Queuename = System.Configuration.ConfigurationManager.AppSettings["Queuename"];

            // Define the name of the channel to use (applies to client connections only) 
            Channel = System.Configuration.ConfigurationManager.AppSettings["Channel"];
           
            connectionProperties = new Hashtable();
            connectionProperties.Add(MQC.HOST_NAME_PROPERTY, Hostname);
            //connectionProperties.Add(MQC.)
            connectionProperties.Add(MQC.CHANNEL_PROPERTY, Channel);
            connectionProperties.Add(MQC.PORT_PROPERTY, Port);
            connectionProperties.Add(MQC.CONNECT_OPTIONS_PROPERTY, HostIp);

            //MQQueueManager qMgr = new MQQueueManager(qManager, connectionProperties);
           // int openOptions = MQC.MQOO_INPUT_AS_Q_DEF | MQC.MQOO_OUTPUT;
            //MQQueue system_default_local_queue =
                 // qMgr.AccessQueue("SYSTEM.DEFAULT.LOCAL.QUEUE", openOptions);

        }

    }
}
