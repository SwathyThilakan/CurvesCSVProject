﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurvesCSVClient
{
    public class MQRequest
    {
        string message;
        public string Message
        {
            get
                { return message; }
            set
                { value = message;}
        }

    }
}
