﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Diagnostics;
using System.IO;

namespace CurvesCSVClient
{
    public class Model
    {
        Thread mqMonitor;
        public string message;
        List<Curves> curvesList = new List<Curves>();
        MQHelper helper = new MQHelper();
        public void PassToMQ(string message)
        {
            try
            {
                helper.WriteMessage(message);
            }
            catch (Exception ex)
            {
                EventLog.WriteEntry("CurvesCSVClient", string.Format("An exception occured while writing to MQ: {0}", ex.ToString()));
            }
        }

        // public 
        public Curves GetFromMQ()
        {
            string[] messageList = new string[6];
            Curves curve = new Curves();
            try
            {
                message = helper.ReadMessage();
                if (!string.IsNullOrEmpty(message))
                {
                    messageList = message.Split('|');
                    curve.Index = messageList[0];
                    curve.A = messageList[1];
                    curve.A2 = messageList[2];
                    curve.B = messageList[3];
                    curve.C = messageList[4];

                    curvesList.Add(curve);
                }
                else
                {
                    curve = null;
                }
            }
            catch (Exception ex)
            {
                curve = null;
                EventLog.WriteEntry("CurvesCSVClient", string.Format("An exception occured while trying to read from MQ: {0}", ex.ToString()));
            }
            return curve;
        }

        public void ExportAsXML()
        {
            FileInfo file = new FileInfo("CurvesCSVXML" + ".xml");
            StreamWriter sw = file.AppendText();
            var writer = new System.Xml.Serialization.XmlSerializer(typeof(List<Curves>));
            writer.Serialize(sw, curvesList);
            sw.Close();
        }

    }
}
