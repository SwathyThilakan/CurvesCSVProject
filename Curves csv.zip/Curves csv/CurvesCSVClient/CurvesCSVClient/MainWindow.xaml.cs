﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Threading;

namespace CurvesCSVClient
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        bool enable;
        Thread fillTable;
        Model model = new Model();
        public MainWindow()
        {
            InitializeComponent();


        }

        public void FillTable()
        {
            int cols = 5;
            int rows = 1;

            //for (int c = 0; c < cols; c++)
            myTable.Columns.Add(new TableColumn());

            for (int r = 0; r < rows; r++)
            {
                TableRow tr = new TableRow();

                tr.Cells.Add(new TableCell(new Paragraph(new Run("Index"))));
                tr.Cells.Add(new TableCell(new Paragraph(new Run("A"))));
                tr.Cells.Add(new TableCell(new Paragraph(new Run("A2"))));
                tr.Cells.Add(new TableCell(new Paragraph(new Run("B"))));
                tr.Cells.Add(new TableCell(new Paragraph(new Run("C"))));

                TableRowGroup trg = new TableRowGroup();
                trg.Rows.Add(tr);
                myTable.RowGroups.Add(trg);

                fillTable = new Thread(new ThreadStart(AddRowToTable));
                fillTable.Start();
            }
        }

        public void AddRowToTable()
        {
            try
            {
                Curves curve = model.GetFromMQ();
                if (curve != null)
                {
                    TableRow tr = new TableRow();

                    //for (int c = 0; c < cols; c++)
                    tr.Cells.Add(new TableCell(new Paragraph(new Run(curve.Index))));
                    tr.Cells.Add(new TableCell(new Paragraph(new Run(curve.A))));
                    tr.Cells.Add(new TableCell(new Paragraph(new Run(curve.A2))));
                    tr.Cells.Add(new TableCell(new Paragraph(new Run(curve.B))));
                    tr.Cells.Add(new TableCell(new Paragraph(new Run(curve.C))));

                    TableRowGroup trg = new TableRowGroup();
                    trg.Rows.Add(tr);
                    myTable.RowGroups.Add(trg);
                }
            }
            catch (Exception ex)
            {

            }
        }

        private void rbnSelected_Checked(object sender, RoutedEventArgs e)
        {
            sPanel2.Visibility = Visibility.Visible;
            sPanel3.Visibility = Visibility.Visible;
        }


        private void rbnWhole_Checked(object sender, RoutedEventArgs e)
        {
            sPanel3.Visibility = Visibility.Visible;
        }

        private void btnSubmit_Click(object sender, RoutedEventArgs e)
        {
            MQRequest request = new MQRequest();
            if (rbnWhole.IsChecked == true)
            {
                request.Message = "All";
            }
            else
            {
                int r1 = new int();
                int r2 = new int();
                if (string.IsNullOrEmpty(tbStrt.Text))
                {
                    if (int.TryParse(tbStrt.Text, out r1))
                    {
                        if (int.TryParse(tbStrt.Text, out r2))
                        {
                            request.Message = tbStrt.Text + "-" + tbEnd.Text;


                        }
                        else
                        {
                            txtBlk.Text += "  Integer values to be provided for end block";
                        }
                    }
                    else
                    {
                        txtBlk.Text += "  Integer values to be provided for start block";
                    }
                }
                else
                {
                    txtBlk.Text += "    Start value cannot be empty";
                }

            }
        }

        private void tbEnd_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void btnExport_Click(object sender, RoutedEventArgs e)
        {
            model.ExportAsXML();
        }
    }
}
