﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using IBM.WMQ;

namespace CurvesCSVClient
{
    public class MQHelper
    {
        public MQHelper()
        {
            Connect();
        }

        MQQueueManager mgr;
        MQClient client;
        public void Connect()
        {
            try
            {
                client = new MQClient();
                MQEnvironment.Hostname = client.Hostname;
                MQEnvironment.Channel = client.Channel;
                MQEnvironment.Port = Convert.ToInt32(client.Port);


                mgr = new MQQueueManager("MQMGR", client.Channel, client.HostIp + "(" + client.Port + ")");
            }
            catch (Exception ex)
            {
                throw new Exception(ex.ToString());
            }
        }

        public string ReadMessage()
        {
            string returnMessage = string.Empty;
            try
            {
                if (mgr != null && mgr.IsConnected)
                {
                    MQQueue queue = mgr.AccessQueue(client.Queuename, MQC.MQOO_BIND_AS_Q_DEF + MQC.MQOO_FAIL_IF_QUIESCING);
                    MQMessage message = new MQMessage();
                    message.Format = MQC.MQFMT_STRING;
                    MQGetMessageOptions options = new MQGetMessageOptions();
                    queue.Get(message, options);
                    returnMessage = message.ReadString(message.MessageLength);
                }
                else
                {
                    returnMessage = string.Empty;
                    throw new Exception("Connection Not Established");
                }
            }

            catch (Exception e)
            {
                returnMessage = e.ToString();
            }
            return returnMessage;
        }

        public void WriteMessage(string request)
        {
            try
            {
                if (mgr != null && mgr.IsConnected)
                {
                    MQQueue queue = mgr.AccessQueue(client.Queuename, MQC.MQOO_OUTPUT + MQC.MQOO_FAIL_IF_QUIESCING);
                    MQMessage message = new MQMessage();
                    message.Format = MQC.MQFMT_STRING;
                    message.WriteString(request);
                    MQPutMessageOptions options = new MQPutMessageOptions();
                    queue.Put(message, options);

                }
                else
                {
                    throw new Exception("Connection Not Established");
                }
            }
            catch (Exception e)
            {

            }

        }
    }
}
