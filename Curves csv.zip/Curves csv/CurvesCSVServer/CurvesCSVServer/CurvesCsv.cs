﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace CurvesCSVServer
{
    public partial class CurvesCsv : ServiceBase
    {
        Curves curves = new Curves();
        MQClient client = new MQClient();
        MQHelper helper = new MQHelper();
        public CurvesCsv()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            initialSetups();
        }

        protected override void OnStop()
        {
        }

        public void ReadFromMQ()
        {
            List<Curves> curvesList = new List<Curves>();
            try
            {
                //MQHelper helper = new MQHelper();
                string entries = helper.ReadMessage();
                curvesList = TextToCurvesConvert.returnList(entries);
                if (curvesList != null && curvesList.Count > 0)
                    FrameMessage(curvesList);
            }
            catch(Exception ex)
            {
                EventLog.WriteEntry("CSVServer", ex.ToString());
            }
        }

        public void WriteToMQ()
        {

        }
        public void initialSetups()
        {
            //MQHelper helper = new MQHelper();
           // helper.WriteMessage();
            List<Curves> curvesList = new List<Curves>();
            curvesList = TextToCurvesConvert.convertFromTxttoObj();
        }

        public void FrameMessage(List<Curves> curves)
        {
            string message = string.Empty;
            foreach(Curves cs in curves)
            {
                message = cs.Index + '|' + cs.A + '|' + cs.A2 + '|' + cs.B + '|' + cs.C;
                helper.WriteMessage(message);
                Thread.Sleep(1000);
            }
        }
    }
}
