﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Configuration;

namespace CurvesCSVServer
{
    public static class TextToCurvesConvert
    {

        static Curves curves = new Curves();
        /// <summary>
        /// Converts the file to string array
        /// </summary>
        /// <returns>string[] filetext</returns>
        public static string[] readFromFile()
        {
            string[] fileText = File.ReadAllLines(System.Configuration.ConfigurationManager.AppSettings["Path"]);
            return fileText;
        }
        /// <summary>
        /// Converts the string from file to Curves object
        /// </summary>
        /// <param name="txtFile"></param>
        /// <returns>list of curves</returns>
        public static List<Curves> convertFromTxttoObj()
        {
            string[] txtFile = readFromFile();
            List<Curves> curvesList = new List<Curves>();
            Curves tempCurve = new Curves();
            for (int i = 1; i < txtFile.Length; i++)
            {
                string[] strAry = txtFile[i].Split(',');
                tempCurve.Index = strAry[0];
                tempCurve.A = strAry[1];
                tempCurve.A2 = strAry[2];
                tempCurve.B = strAry[3];
                tempCurve.C = strAry[4];

                curvesList.Add(tempCurve);
            }

            if (curvesList.Count > 0)
            {
                return curvesList;
            }

            else
            {

                return returnInvalidObject();
            }
        }

        /// <summary>
        /// Function to return an invalid object
        /// </summary>
        /// <returns>List of invalid object</returns>
        public static List<Curves> returnInvalidObject()
        {
            List<Curves> listOFInvalid = new List<Curves>();
            Curves invalidCurve = new Curves();
            invalidCurve.Index = "Invalid";

            return listOFInvalid;
        }

        public static List<Curves> returnList(string param)
        {
            List<Curves> curvesList = convertFromTxttoObj();
            if (param == "All")
                return curvesList;
            string[] paramArray = param.Split('-');
            int p1;
            int.TryParse(paramArray[0], out p1);
            int p2;
            int.TryParse(paramArray[1], out p2);
            
            List<Curves> curvesListTemp=new List<Curves>();
            foreach (Curves curve in curvesList)
            {
                
                if ((Convert.ToInt32(curve.Index)>=p1 )&& (Convert.ToInt32(curve.Index)<= p2))
                {
                    curvesListTemp.Add(curves);
                }
            }

            return curvesListTemp;
        }
    }
}
