﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CurvesCSVServer
{
    public class MQConnectionFailureException : Exception
    {
        string exceptionText;
        public MQConnectionFailureException(string exceptionType)
        {
            exceptionText = exceptionType;
        }
    }
}
