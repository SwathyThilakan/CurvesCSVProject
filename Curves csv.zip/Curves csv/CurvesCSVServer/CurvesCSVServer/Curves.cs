﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.IO;

namespace CurvesCSVServer
{
    public class Curves
    {
        private string index;
        private string a;
        private string a2;
        private string b;
        private string c;

        public string Index
        {
            get { return index; }
            set { index = value; }
        }

        public string A
        {
            get { return a; }
            set { a = value; }
        }

        public string A2
        {
            get { return a2; }
            set { a2 = value; }
        }

        public string B
        {
            get { return b; }
            set { b = value; }
        }

        public string C
        {
            get { return c; }
            set { c = value; }
        }
     
    }

}